let bg = document.getElementById("Background");
let Kristian = document.getElementById("Kristian");
let sol = document.getElementById("Sol");
let sleven = document.getElementById("Sleven");
let text = document.getElementById("text");

window.addEventListener('scroll', function(){
    var value = window.scrollY;
    bg.style.top = value * 0.5 + 'px';
    Kristian.style.top = value * 0.5 + 'px';
    sol.style.top = value * 0.5 + 'px';
    sleven.style.top = value * 0.5 + 'px';
    sleven.style.top = value * 0.5 + 'px';
})